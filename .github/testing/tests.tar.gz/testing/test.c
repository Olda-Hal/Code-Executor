#include <stdio.h>

int main() {
    printf("Debug: This is a debug message.\n");
    return 0;
}