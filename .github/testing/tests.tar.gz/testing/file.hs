main :: IO ()
main = putStrLn "Hello, World!"