import requests

with open('test.tar.gz', 'rb') as file:
    project = file.read()
    project_hex = project.hex()


response = requests.post("http://localhost:8000/execute", json={
    "language": "haskell",
    "project": project_hex,
    "execfile": "testing/file.hs",
    "timeout": 100
})
print(response)
print(response.json()["stdout"])
print(response.json()["stderr"])
print(response.json())