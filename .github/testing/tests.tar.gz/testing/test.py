import time

time.sleep(10)
print("timeout 10s")